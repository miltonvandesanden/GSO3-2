README Fontys Publisher
TODO