README Fontys Publisher
TODO