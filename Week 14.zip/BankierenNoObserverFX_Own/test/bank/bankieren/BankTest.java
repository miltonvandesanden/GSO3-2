/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bank.bankieren;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Stefan
 */
public class BankTest {
    
    Bank instance = null;
    Bank sameInstance = new Bank("ING");
    public BankTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        instance = new Bank("Rabobank");
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of openRekening method, of class Bank.
     */
    @Test
    public void testOpenRekeningGeenNaam() {
        System.out.println("testOpenRekeningGeenNaam");
        String name = "";
        String city = "Waspik";
        int expResult = -1;
        int result = instance.openRekening(name, city);
        assertEquals(expResult, result);
    }
    
    @Test
    public void testOpenRekeningGeenStad() {
        System.out.println("testOpenRekeningGeenStad");
        String name = "Hans";
        String city = "";
        int expResult = -1;
        int result = instance.openRekening(name, city);
        assertEquals(expResult, result);
    }

    @Test
    public void testOpenRekeningStadEnNaam() {
        System.out.println("testOpenRekeningStadEnNaam");
        String name = "Hans";
        String city = "Waspik";
        int expResult = 100000000;
        int result = instance.openRekening(name, city);
        assertEquals(expResult, result);
    }
    /**
     * Test of getRekening method, of class Bank.
     */
    @Test
    public void testGetRekening() {
        System.out.println("testGetRekening");
        
        int rekeningnr = instance.openRekening("Hanse", "Waspik");
        IRekening result = instance.getRekening(rekeningnr);
        
        
        IRekening expResult = new Rekening(100000000, new Klant("Hans", "Waspik"), Money.EURO);
        
        assertEquals(expResult, result);
    }

    /**
     * Test of maakOver method, of class Bank.
     */
    ///TODO: this
    @Test
    public void testMaakOver() throws Exception {
        System.out.println("testMaakOver");
        int source = 0;
        int destination = 0;
        Money money = null;
        Bank instance = null;
        boolean expResult = false;
        boolean result = instance.maakOver(source, destination, money);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getName method, of class Bank.
     */
    @Test
    public void testGetName() {
        System.out.println("testGetName");
        
        String expResult = "Rabobank";
        String result = instance.getName();
        assertEquals(expResult, result);
    }
}
